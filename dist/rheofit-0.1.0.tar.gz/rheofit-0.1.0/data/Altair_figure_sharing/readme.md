Some tests on good way to share small amount of structured data

see https://github.com/rheopy/rheofit/blob/master/data/Altair_figure_sharing/Sharing_figures_and_data_with_altair.ipynb the notebook in this directory for more information



